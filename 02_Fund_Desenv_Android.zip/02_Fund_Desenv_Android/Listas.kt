/**
 * You can edit, run, and share this code. 
 * play.kotlinlang.org 
 */

const val PROIBIDO = -1
const val FACULTATIVO = 0
const val OBRIGATORIO = 1
fun deveVotar(idade: Int): Int{
    when(idade) {
         in 18..69 -> return OBRIGATORIO
         in 0..15 -> return PROIBIDO
         else -> return FACULTATIVO
    }
}

fun main(){
    val idades:List<Int> = listOf(25, 13, 17, 80, 69, 70)
    for(idade in idades){
        when(deveVotar(idade)){
            PROIBIDO -> println("$idade anos NÃO PODE votar!")
            FACULTATIVO -> println("$idade anos vota SE QUISER.")
            OBRIGATORIO -> println("$idade anos É OBRIGADO a votar!")
        }
    }
}